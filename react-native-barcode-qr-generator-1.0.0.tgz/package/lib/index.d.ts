import React from 'react';
import { ViewStyle, TextStyle, StyleProp } from 'react-native';
export type BarcodeFormat = 'CODE39' | 'CODE128' | 'CODE128A' | 'CODE128B' | 'CODE128C' | 'EAN13' | 'EAN8' | 'EAN5' | 'EAN2' | 'UPC' | 'UPCE' | 'ITF14' | 'ITF' | 'MSI' | 'MSI10' | 'MSI11' | 'MSI1010' | 'MSI1110' | 'pharmacode' | 'codabar';
export type CodeType = 'barcode' | 'qrcode';
export interface BarcodeProps {
    /**
     * The type of code to generate
     * @default 'barcode'
     */
    type?: CodeType;
    /**
     * The text to be encoded
     */
    value: string;
    /**
     * The width of a single bar
     * @default 2
     */
    width?: number;
    /**
     * The max width of the barcode
     */
    maxWidth?: number;
    /**
     * The height of the barcode
     * @default 100
     */
    height?: number;
    /**
     * select which barcode type to use
     * @default 'CODE128'
     */
    format?: BarcodeFormat;
    /**
     * set the color of a single bar
     * @default '#000000'
     */
    lineColor?: string;
    /**
     * set the color of the container
     * @default '#ffffff'
     */
    background?: string;
    /**
     * an optional text that will be render under the barcode
     */
    text?: React.ReactNode;
    /**
     * styles to be applied on the text component
     */
    textStyle?: StyleProp<TextStyle>;
    /**
     * styles to be applied on the container
     */
    style?: StyleProp<ViewStyle>;
    /**
     * an optional error handler
     */
    onError?: (error: Error) => void;
}
declare const Barcode: React.FC<BarcodeProps>;
export default Barcode;
