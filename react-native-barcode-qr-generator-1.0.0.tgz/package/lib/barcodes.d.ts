export declare class BarcodeEncoder {
    value: string;
    options: any;
    constructor(value: string, options: any);
    valid(): boolean;
    encode(): {
        data: string;
    };
}
export declare class CODE128 extends BarcodeEncoder {
    valid(): boolean;
    encode(): {
        data: string;
    };
}
declare const barcodeMapping: Record<string, any>;
export default barcodeMapping;
