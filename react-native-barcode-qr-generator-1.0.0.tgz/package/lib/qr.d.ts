/**
 * A minimal QR Code generator implementation
 * Based on qrcode-generator by Kazuhiko Arase
 */
type QRMode = 1 | 2 | 4 | 8;
type QRErrorCorrectionLevel = 'L' | 'M' | 'Q' | 'H';
interface QRBitBuffer {
    buffer: number[];
    length: number;
    get(index: number): boolean;
    put(num: number, length: number): void;
    putBit(bit: boolean): void;
}
export declare class QRCodeModel {
    typeNumber: number;
    errorCorrectionLevel: QRErrorCorrectionLevel;
    modules: (boolean | null)[][];
    moduleCount: number;
    dataCache: number[] | null;
    dataList: {
        mode: QRMode;
        data: string;
    }[];
    constructor(typeNumber: number, errorCorrectionLevel: QRErrorCorrectionLevel);
    addData(data: string): void;
    isDark(row: number, col: number): boolean;
    getModuleCount(): number;
    make(): void;
    private makeImpl;
    private setupPositionProbePattern;
    private getBestMaskPattern;
    private setupTimingPattern;
    private setupPositionAdjustPattern;
    private setupTypeNumber;
    private setupTypeInfo;
    private mapData;
    private getBestTypeNumber;
    static createData(typeNumber: number, errorCorrectionLevel: QRErrorCorrectionLevel, dataList: {
        mode: QRMode;
        data: string;
    }[]): number[];
    static createBytes(buffer: QRBitBuffer, rsBlocks: QRRSBlock[]): number[];
}
declare class QRRSBlock {
    totalCount: number;
    dataCount: number;
    constructor(totalCount: number, dataCount: number);
    static rsBlockTable: number[][];
    static getRSBlocks(typeNumber: number, errorCorrectionLevel: QRErrorCorrectionLevel): QRRSBlock[];
    static getRsBlockTable(typeNumber: number, errorCorrectionLevel: QRErrorCorrectionLevel): number[] | null;
    static rsBlockTableL: number[][];
    static rsBlockTableM: number[][];
    static rsBlockTableQ: number[][];
    static rsBlockTableH: number[][];
}
export {};
